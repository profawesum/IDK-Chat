
#include <chrono>

#include "timer.h"

Timer::Timer() 
	: timeElapsed(0.0f)
	, deltaTime(0.0f){

}

Timer::~Timer(){


}

bool Timer::Initialise(){

	currentTime = chrono::high_resolution_clock::now();

	return true;
}

void Timer::Process(){

	lastTime = currentTime;
	currentTime = chrono::high_resolution_clock::now();
	deltaTime = chrono::duration_cast<chrono::milliseconds>(currentTime - lastTime).count();
	timeElapsed += deltaTime;
}

float Timer::GetDeltaTick(){
	return(deltaTime);
}
