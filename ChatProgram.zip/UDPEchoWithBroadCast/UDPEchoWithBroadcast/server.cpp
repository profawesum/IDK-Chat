//
// (c) 2015 Media Design School
//
// File Name	: 
// Description	: 
// Author		: Your Name
// Mail			: your.name@mediadesign.school.nz
//

//Library Includes
#include <WS2tcpip.h>
#include <iostream>
#include <utility>
#include <thread>
#include <chrono>


//Local Includes
#include "utils.h"
#include "network.h"
#include "consoletools.h"
#include "socket.h"


//Local Includes
#include "server.h"

using namespace std;


CServer::CServer()
	:m_pcPacketData(0),
	m_pServerSocket(0)
{
	ZeroMemory(&m_ClientAddress, sizeof(m_ClientAddress));
}

CServer::~CServer()
{
	delete m_pConnectedClients;
	m_pConnectedClients = 0;

	delete m_pServerSocket;
	m_pServerSocket = 0;

	delete m_pWorkQueue;
	m_pWorkQueue = 0;
	
	delete[] m_pcPacketData;
	m_pcPacketData = 0;
}

bool CServer::Initialise()
{
	m_pcPacketData = new char[MAX_MESSAGE_LENGTH];
	
	//Create a work queue to distribute messages between the main  thread and the receive thread.
	m_pWorkQueue = new CWorkQueue<std::pair<sockaddr_in, std::string>>();

	//Create a socket object
	m_pServerSocket = new CSocket();

	//Get the port number to bind the socket to
	unsigned short _usServerPort = QueryPortNumber(DEFAULT_SERVER_PORT);

	//Initialise the socket to the local loop back address and port number
	if (!m_pServerSocket->Initialise(_usServerPort))
	{
		return false;
	}

	//Qs 2: Create the map to hold details of all connected clients
	m_pConnectedClients = new std::map < std::string, TClientDetails >() ;

	return true;
}

bool CServer::AddClient(std::string _strClientName)
{
	//TO DO : Add the code to add a client to the map here...
	
	for (auto it = m_pConnectedClients->begin(); it != m_pConnectedClients->end(); ++it)
	{
		//Check to see that the client to be added does not already exist in the map, 
		if(it->first == ToString(m_ClientAddress))
		{
			cout << "Address already in use" << endl;
			return false;
		}
		//also check for the existence of the username
		else if (it->second.m_strName == _strClientName)
		{
			cout << "An existing user already exsists" << endl;

			TPacket _packetToSend;
			string errorMessage = "Invalid Username";
			_packetToSend.Serialize(HANDSHAKE, const_cast<char*>(errorMessage.c_str()));
			SendData(_packetToSend.PacketData);
			
			for (const auto it : *m_pConnectedClients) {
				cout << it.first << " ";
			}
			cout << endl;
			return false;
		}
	}

	cout << "Client being added" << endl;
	for (const auto it : *m_pConnectedClients) {
		cout << it.first << " ";
	}
	cout << endl;


	//Add the client to the map.
	TClientDetails _clientToAdd;
	_clientToAdd.m_strName = _strClientName;
	_clientToAdd.m_ClientAddress = this->m_ClientAddress;

	std::string _strAddress = ToString(m_ClientAddress);
	m_pConnectedClients->insert(std::pair < std::string, TClientDetails > (_strAddress, _clientToAdd));
	return true;
}

bool CServer::SendData(char* _pcDataToSend)
{
	int _iBytesToSend = (int)strlen(_pcDataToSend) + 1;
	
	
		int iNumBytes = sendto(
			m_pServerSocket->GetSocketHandle(),				// socket to send through.
			_pcDataToSend,									// data to send
			_iBytesToSend,									// number of bytes to send
			0,												// flags
			reinterpret_cast<sockaddr*>(&m_ClientAddress),	// address to be filled with packet target
			sizeof(m_ClientAddress)							// size of the above address struct.
		);
		//iNumBytes;
		if (_iBytesToSend != iNumBytes)
		{
			std::cout << "There was an error in sending data from client to server" << std::endl;
			return false;
		}
		return true;
}

bool CServer::SendDataTo(char* _pcDataToSend, sockaddr_in _clientAdrress)
{
	int _iBytesToSend = (int)strlen(_pcDataToSend) + 1;

		int iNumBytes = sendto(
			m_pServerSocket->GetSocketHandle(),				// socket to send through.
			_pcDataToSend,									// data to send
			_iBytesToSend,									// number of bytes to send
			0,												// flags
			reinterpret_cast<sockaddr*>(&_clientAdrress),	// address to be filled with packet target
			sizeof(_clientAdrress)							// size of the above address struct.
		);


		//iNumBytes;
		if (_iBytesToSend != iNumBytes)
		{
			std::cout << "There was an error in sending data from client to server" << std::endl;
			return false;
		}
		return true;
}

//receives messages
void CServer::ReceiveData(char* _pcBufferToReceiveData)
{
	
	int iSizeOfAdd = sizeof(m_ClientAddress);
	int _iNumOfBytesReceived;
	int _iPacketSize;

	//Make a thread local buffer to receive data into
	char _buffer[MAX_MESSAGE_LENGTH];

	while (true)
	{
		// pull off the packet(s) using recvfrom()
		_iNumOfBytesReceived = recvfrom(			// pulls a packet from a single source...
			m_pServerSocket->GetSocketHandle(),						// client-end socket being used to read from
			_buffer,							// incoming packet to be filled
			MAX_MESSAGE_LENGTH,					   // length of incoming packet to be filled
			0,										// flags
			reinterpret_cast<sockaddr*>(&m_ClientAddress),	// address to be filled with packet source
			&iSizeOfAdd								// size of the above address struct.
		);
		if (_iNumOfBytesReceived < 0)
		{
			int _iError = WSAGetLastError();
			ErrorRoutines::PrintWSAErrorInfo(_iError);
			//return false;
		}
		else
		{
			_iPacketSize = static_cast<int>(strlen(_buffer)) + 1;
			strcpy_s(_pcBufferToReceiveData, _iPacketSize, _buffer);
			char _IPAddress[100];
			inet_ntop(AF_INET, &m_ClientAddress.sin_addr, _IPAddress, sizeof(_IPAddress));
			
			std::cout << "Server Received \"" << _pcBufferToReceiveData << "\" from " <<
				_IPAddress << ":" << ntohs(m_ClientAddress.sin_port) << std::endl;
			//Push this packet data into the WorkQ
			m_pWorkQueue->push(std::make_pair(m_ClientAddress,_pcBufferToReceiveData));
		}
		//std::this_thread::yield();
		
	} //End of while (true)
}

void CServer::GetRemoteIPAddress(char *_pcSendersIP)
{
	char _temp[MAX_ADDRESS_LENGTH];
	int _iAddressLength;
	inet_ntop(AF_INET, &(m_ClientAddress.sin_addr), _temp, sizeof(_temp));
	_iAddressLength = static_cast<int>(strlen(_temp)) + 1;
	strcpy_s(_pcSendersIP, _iAddressLength, _temp);
}

unsigned short CServer::GetRemotePort()
{
	return ntohs(m_ClientAddress.sin_port);
}


void CServer::ProcessData(std::pair<sockaddr_in, std::string> dataItem)
{
	TPacket _packetRecvd, _packetToSend;
	_packetRecvd = _packetRecvd.Deserialize(const_cast<char*>(dataItem.second.c_str()));

	string message;

	switch (_packetRecvd.MessageType)
	{
	case HANDSHAKE:
	{
		cout << "Server received a handshake message" << endl;
		if (const_cast<char*>(dataItem.second.c_str()) == "Keep Alive") {
			cout << "Keep alive packet" << endl;
			return;
		}

		for (const auto it : *m_pConnectedClients) {
			if (it.second.m_strName == _packetRecvd.MessageContent) {

				cout << "Error: User has entered an invalid username" << endl;	
				message = "Invalid Username";
				_packetToSend.Serialize(HANDSHAKE, const_cast<char*>(message.c_str()));
				SendData(_packetToSend.PacketData);
				return;

			}
		}

		AddClient(_packetRecvd.MessageContent);

#pragma region "Entry Message"

		cout << "User " << const_cast<char*>(dataItem.second.c_str()) << "Joined successfully" << endl;
		string userName(const_cast<char*>(dataItem.second.c_str()));
		userName.erase(0, 2);
		message = userName + " joined the server";
		_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
		SendData(_packetToSend.PacketData);
		message = "Current user list:";
		_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
		SendData(_packetToSend.PacketData);

		for (const auto it : *m_pConnectedClients) {
			message = it.second.m_strName;
			_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
			SendData(_packetToSend.PacketData);
		}
		//letting users know another user has joined
		for (const auto it : *m_pConnectedClients) {
			if (it.first == userName) continue;
			m_ClientAddress = it.second.m_ClientAddress;
			message = "[SERVER]: " + userName + " has joined the fray";
			_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
			SendData(_packetToSend.PacketData);
		}
		break;

#pragma endregion
	}
	case DATA:
	{


		cout << "server received a message" << endl;
		string clientName;
		string message = _packetRecvd.MessageContent;

		auto it = m_pConnectedClients->find(ToString(m_ClientAddress));
		if (it == m_pConnectedClients->end()) {
			cout << "Was not found" << endl;
			return;
		}
		else if (message.substr(1, 6) == "!q") {
			cout << "Quit command" << endl;

			//TODO Let everyone know that a user has disconnected

			//sending the disconnect message to the user
			TPacket laterPacket;
			message = "You have been disconnected";
			laterPacket.Serialize(DATA, const_cast<char*>(message.c_str()));
			SendData(laterPacket.PacketData);

			//letting other user know that someone has left
			string userName(const_cast<char*>(dataItem.second.c_str()));
			message = "[SERVER] " + userName + " has Left";
			for (auto itQuit : *m_pConnectedClients) {
				m_ClientAddress = itQuit.second.m_ClientAddress;
				_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
				SendData(_packetToSend.PacketData);

			}

			//removing the user from the connected client list
			auto it = m_pConnectedClients->find(ToString(m_ClientAddress));
			if (it != m_pConnectedClients->end()) {
				m_pConnectedClients->erase(it);
			}
	
			return;
		}


		it->second.timeSinceLastMessage = 0.0f;
		clientName = it->second.m_strName;
		clientName.erase(0, 1);
		//getting the message
		message = "[" + clientName + "]" + _packetRecvd.MessageContent;
		//iterating through all clients
		for (auto it1 : *m_pConnectedClients) {
			//gets the next client
			m_ClientAddress = it1.second.m_ClientAddress;
			//sends the message to the client
			_packetToSend.Serialize(DATA, const_cast<char*>(message.c_str()));
			SendData(_packetToSend.PacketData);
		}
		break;
	}

	case BROADCAST:
	{
		std::cout << "Received a broadcast packet" << std::endl;
		//Just send out a packet to the back to the client again which will have the server's IP and port in it's sender fields
		_packetToSend.Serialize(BROADCAST, "I'm here!");
		SendData(_packetToSend.PacketData);
		break;
	}

	default:
		break;

	}
}

CWorkQueue<std::pair<sockaddr_in, std::string>>* CServer::GetWorkQueue()
{
	return m_pWorkQueue;
}



void CServer::KeepAliveCheck() {

	TPacket keepAlive;
	keepAlive.Serialize(KEEPALIVE, "Keep Alive");

	for (auto it : *m_pConnectedClients) {
		m_ClientAddress = it.second.m_ClientAddress;
		SendData(keepAlive.PacketData);
	}

}

void CServer::IncrimentTimers(float TimeDelta){
	for (auto it : *m_pConnectedClients) {
		it.second.timeSinceLastMessage += TimeDelta;
	}
}
