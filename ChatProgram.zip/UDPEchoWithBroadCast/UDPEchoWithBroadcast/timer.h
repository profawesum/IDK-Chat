#pragma once


#include <chrono>
#include <vector>

using namespace std;


class Timer {



public :

	Timer();
	~Timer();

	bool Initialise();
	void Process();
	float GetDeltaTick();


private:
	Timer(const Timer& _kr);
	Timer& operator= (const Timer& _kr);


protected:

	double timeElapsed;
	double deltaTime;
	chrono::high_resolution_clock::time_point lastTime;
	chrono::high_resolution_clock::time_point currentTime;

	vector<double> vecTimeHistory;

	long long llNumCounts;

};
